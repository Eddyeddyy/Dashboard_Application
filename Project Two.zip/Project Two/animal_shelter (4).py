from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    
    def __init__(self, username, password):
        #Initializing the MongoCLient
        self.client = MongoClient('mongodb://%s:%s@localhost:55821' % (username, password))
        # the databas we are using is AAC
        self.database = self.client['AAC']
        
    def create(self, data):
        # Making sure that the data is not empty before attempting to creat
        if data is not None:
            # inserts data to database
            self.database.animals.insert(data)
            #gives user feedback that insertion was complete
            print("Insertion of document successful")
            return True
        else:
            # if data is absent throws exception
            raise Exception("Nothing to save, because data parameter is empty")
            
    def read(self, data):
        # Making sure data is not empty before attempting to find
        if data is not None:
            #returns the value of the data we search for
            return self.database.animals.find_one(data)
        else:
            #if data is empty throws exception
            raise Exception("No data")
            
    def readAll(self, data):
        #making sure data is not empty before attempting to find
        if data is not None:
            #returns a collection of items that match our search
            cursor = self.database.animals.find(data, {'_id':False})
            return cursor
        else:
            #if data is empty throws a no data exception
            raise Exception("No data")
            
    def update(self, data, updateData):
        #making sure data and update data is not empty before attempting to find
        if data is not None and updateData is not None:
            #assigns update data with the set boundary to not loose any document data
            newData = {"$set": updateData}
            #updates the document in the databse that is found
            self.database.animals.update(data, newData)
            #gives user feedback that file was updated
            print("File updated successfully")
        else:
            #if data is empty throws a no data exception
            raise Exception("No data")
            
    def remove(self, data):
        #making sure data is not empty before attempting to find
        if data is not None:
            #removes just the first file found that mathces data
            self.database.animals.delete_one(data)
            #gives user feedback that file was removed
            print("File removed successfully")
        else:
            #if data is empty throws a no data exception
            raise Exception("No Data")
            
    def removeAll(self, data):
        #making sure data is not empty before attempting to find
        if data is not None:
            #removes all documents that match data
            self.database.animals.delete(data)
            #gives user feedback that file was removed
            print("Files removed successfully")
        else:
            #if data is empty throws a no data exception
            raise Exception("No Data")